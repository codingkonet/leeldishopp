<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/cart.php';

start_session();

$lang = current_lang();
$dict = load_dictionary($lang);
$isRtl = $lang === 'ar';
$pdo = get_pdo();
