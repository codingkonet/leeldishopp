<?php
require __DIR__ . '/../includes/bootstrap.php';

logout_user();
redirect(href_page('index.php'));
